"use client";

import React from "react";

const Error = () => {
  return <div>Route doesn&apos;t exists!</div>;
};

export default Error;
