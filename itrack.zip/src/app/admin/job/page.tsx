import Header from "@/components/Header";
import React from "react";

const Job = () => {
  return (
    <div>
      <Header />
    </div>
  );
};

export default Job;
