import React from "react";

const Certificate = () => {
  return <div>Certificate</div>;
};

export default Certificate;
