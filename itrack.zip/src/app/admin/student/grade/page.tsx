import React from "react";

const Grade = () => {
  return <div>Grade</div>;
};

export default Grade;
