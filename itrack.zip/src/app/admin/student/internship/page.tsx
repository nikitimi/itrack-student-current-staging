import React from "react";

const Internship = () => {
  return <div>Internship</div>;
};

export default Internship;
