import React from "react";

const Footer = () => {
  return <footer>Footer</footer>;
};

export default Footer;
