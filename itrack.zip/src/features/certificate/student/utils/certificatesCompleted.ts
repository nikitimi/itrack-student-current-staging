const certificatesCompleted = 2;

export default certificatesCompleted;
