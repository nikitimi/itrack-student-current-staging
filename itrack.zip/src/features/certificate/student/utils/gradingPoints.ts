const gradingPoints = {
  // A: 14,
  A: 50,
  // B: 6,
  B: 3,
  // C: 1,
  C: 1,
};

export default gradingPoints;
