import type PossibleJob from '@/utils/types/possibleJob';

type FinalComputation = Record<PossibleJob, number>;

export default FinalComputation;
