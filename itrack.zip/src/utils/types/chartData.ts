export type ChartData = {
  job: string;
  certificate: number;
  grades: number;
  internship: number;
};
