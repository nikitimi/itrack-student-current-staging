import type { ReactNode } from "react";

export type Children = Readonly<{ children: ReactNode }>;
